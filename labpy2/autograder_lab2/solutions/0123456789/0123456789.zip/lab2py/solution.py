print('Solving')

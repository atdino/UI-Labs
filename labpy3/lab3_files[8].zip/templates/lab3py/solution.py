
print("Hello AI")
